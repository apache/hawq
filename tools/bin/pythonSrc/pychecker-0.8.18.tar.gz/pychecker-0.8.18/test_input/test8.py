"doc"

def func():
    syntax error here
