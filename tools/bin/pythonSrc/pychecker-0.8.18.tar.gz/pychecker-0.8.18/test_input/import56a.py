'doc'

from import56b import Bar

class Foo(Bar):
    'doc'
    def __init__(self):
    	Bar.__init__(self)

