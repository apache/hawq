'doc'

class Bar:
    'doc'
    def __init__(self): pass

