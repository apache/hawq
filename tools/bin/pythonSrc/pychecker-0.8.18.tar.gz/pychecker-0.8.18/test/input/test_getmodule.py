# -*- Mode: Python -*-
# vi:si:et:sw=4:sts=4:ts=4

from getmodule.A import C as one
from getmodule.B import C as two
