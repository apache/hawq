print 'yo'
